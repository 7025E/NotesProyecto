using Notes.Class;
using MongoDB.Driver;


namespace Notes
{
    public partial class Form1 : Form
    {
        IMongoCollection<Nota> NotasList;

        public Form1()
        {
            //Crea objeto para conectar con la BDD y luego usa el metodo de .conect para obtener la colecion
            Conect conectionObj = new Conect();
            NotasList = conectionObj.conect();
            InitializeComponent();
            updateView();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        public void updateView()
        {
            try
            {
                //Es para obtener los datos y luego ponerlos en la tabla
                List<Nota> selectNotes = NotasList.Find(notes => true).ToList();
                MessageBox.Show("Se cargaron las notas");
                int rowNum = 0;


                dataGridView.Rows.Clear(); // Limpiar filas 

                foreach (var n in selectNotes)
                {
                    rowNum = dataGridView.Rows.Add(); // Agrega nueva fila 
                    //Pone en la celda o el  id y asi con los demas
                    dataGridView.Rows[rowNum].Cells[0].Value = n.Id;
                    dataGridView.Rows[rowNum].Cells[1].Value = n.Title;
                    dataGridView.Rows[rowNum].Cells[2].Value = n.Content;
                    dataGridView.Rows[rowNum].Cells[3].Value = string.Join(" , ", n.tags); // toma el array de n.tags u une con ,
                    dataGridView.Rows[rowNum].Cells[4].Value = n.CreatedDate;
                }
                //Elimina para poner todo en Sin titulo
                clearTextArea();
            }
            catch (MongoException)
            {
                MessageBox.Show("No se pudo cargar las notas");
            }
        }

        public void clearTextArea()
        {
            //borrar texto
            titleTA.Text = "Sin titulo";
            tagTA.Text = "Sin tags";
            contentTA.Clear();
            contentTA.Text = "Sin texto";
            createdDateTA.Text = "";
            searchTA.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)//Para agregar una nota
        {
            //Crea un objeto nota y pone lo que estaba en los campos
            Nota note = new Nota() // nota
            {
                Title = titleTA.Text,
                Content = contentTA.Text,
                CreatedDate = DateTime.Now.ToString(),
                tags = new string[] { tagTA.Text }
            };

            try//Intenta agregar nota con insertOne
            {
                NotasList.InsertOne(note);
                MessageBox.Show("Nota agregada");
                updateView();
            }
            catch (MongoException ex)
            {//Si falla al insertar nota
                MessageBox.Show("Nota NO agregada");
            }

        }


        //Update a una nota
        public void updateNota()
        {
            Nota note = new Nota() //Objeto nota con lo que se ba actualizar
            {
                Id = IDTA.Text,
                Title = titleTA.Text,
                Content = contentTA.Text,
                CreatedDate = DateTime.Now.ToString(),
                tags = new string[] { tagTA.Text }
            };

            try//Intenta hacer update a la nota con el id y lo remplaza con la nota de arriba 
            {
                NotasList.ReplaceOne(nota => nota.Id == IDTA.Text.ToString(), note);
                MessageBox.Show("Se actualizo");
                updateView();
            }
            catch (MongoException e)
            {//Si falla muestra mensaje
                MessageBox.Show("No se actualizo");
            }
        }


        public void deleteNota()
        {
            try
            {// Elimina nota con el id 
                NotasList.DeleteOne(note => note.Id == IDTA.Text);
                // Mensaje si se elimino
                MessageBox.Show("Se elimino");
                //Vuelve a actualizar la tabla
                updateView();
            }
            catch (MongoException e)
            {
                MessageBox.Show("No se elimino");
            }
        }

        public void searchNota()
        {
            try
            {
                List<Nota> notesList = NotasList.Find(note => note.Title == searchTA.Text || note.tags.Contains(searchTA.Text)).ToList();
                dataGridView.Rows.Clear(); // Limpiar filas 

                foreach (var n in notesList)
                {
                    int rowNum = dataGridView.Rows.Add(); // Agrega nueva fila 
                    dataGridView.Rows[rowNum].Cells[0].Value = n.Id;
                    dataGridView.Rows[rowNum].Cells[1].Value = n.Title;
                    dataGridView.Rows[rowNum].Cells[2].Value = n.Content;
                    dataGridView.Rows[rowNum].Cells[3].Value = string.Join(" , ", n.tags);//Para unir los del array
                    dataGridView.Rows[rowNum].Cells[4].Value = n.CreatedDate;
                }
                clearTextArea();//para poner todo en blanco
                MessageBox.Show("Se encontro");
            }
            catch (MongoException e)
            {
                MessageBox.Show("No se encontro");
            }
        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)//poner datos en tabla
        {
            //El campo de texto = el campo n de la tabla
            IDTA.Text = dataGridView.SelectedCells[0].Value.ToString();
            titleTA.Text = dataGridView.SelectedCells[1].Value.ToString();
            contentTA.Text = dataGridView.SelectedCells[2].Value.ToString();
            tagTA.Text = dataGridView.SelectedCells[3].Value.ToString();
            createdDateTA.Text = dataGridView.SelectedCells[4].Value.ToString();

        }

        //-----------------------------------------------Cuando se presionan bottones
        //Para deseleccionar
        private void deleteSelectionBTN_Click(object sender, EventArgs e)
        {
            clearTextArea();
        }

        //Update
        private void updateBTN_Click(object sender, EventArgs e)
        {
            updateNota();
        }

        //Eliminar
        private void deleteBTN_Click(object sender, EventArgs e)
        {
            deleteNota();
        }
        //Buscar boton
        private void searchBTN_Click(object sender, EventArgs e)
        {
            searchNota();
        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        ///                                 PARA ELIMINAR EL SIN ..., cuando haces click en el campo (titulo contenido y tags)
        private void mouseDownTitle(object sender, MouseEventArgs e)
        {
            if (titleTA.Text == "Sin titulo")
            {
                titleTA.Text = "";
            }
        }

        private void mouseDownContent(object sender, MouseEventArgs e)
        {
            if (contentTA.Text == "Sin texto")
            {
                contentTA.Text = "";
            }

        }

        private void mouseDownTags(object sender, MouseEventArgs e)
        {
            if (tagTA.Text == "Sin tags")
            {
                tagTA.Text = "";
            }
        }

        //Volver a poner la tabla
        private void reloadBTN_Click(object sender, EventArgs e)
        {
            updateView();
        }
    }
}
