﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;


namespace Notes.Class
{
    public class Nota//internal
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)] // convierte objectid a string
        public string Id { get; set; }

        [BsonElement("title")]
        public string Title { get; set; }

        [BsonElement("content")]
        public string Content { get; set; }

        [BsonElement("createdDate")]
        public string CreatedDate { get; set; }

        [BsonElement("tags")]
        public string [] tags { get; set; }



    }
}
