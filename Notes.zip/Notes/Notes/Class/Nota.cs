﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;


namespace Notes.Class
{
    public class Nota//Clase para guardar las notas de la BDD
    {
        //Guarda id
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)] // convierte objectid a string
        public string Id { get; set; }

        //guarda el atributo title
        [BsonElement("title")]
        public string Title { get; set; }

        //guarda el atributo content
        [BsonElement("content")]
        public string Content { get; set; }

        //guarda el atributo createdDate
        [BsonElement("createdDate")]
        public string CreatedDate { get; set; }

        //guarda el atributo de tags
        [BsonElement("tags")]
        public string [] tags { get; set; }



    }
}
