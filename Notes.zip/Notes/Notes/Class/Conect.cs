﻿using MongoDB.Driver;
using System;

namespace Notes.Class
{
    public class Conect
    {
        public IMongoCollection<Nota> conect(){//obtener todas las notas 
            try     //Try catch por si falla
            {
                //variables para obtener la conexion
                var client = new MongoClient("mongodb://localhost:27017");
                var bdd = client.GetDatabase("NotesBDD");
                //Collecion de notas con 
                var notesCollection = bdd.GetCollection<Nota>("Notes");
                //Mensaje si se conecta
                MessageBox.Show("Conectado");
                //Devolvemos la collecion a la clase 
                return notesCollection;
            }
            catch (MongoException e)
            {
                //Si hay un error de conexion
                MessageBox.Show("No se conecto");
                return null;
            }
        }

    }
}


