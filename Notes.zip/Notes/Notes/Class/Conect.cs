﻿using MongoDB.Driver;
using System;

namespace Notes.Class
{
    public class Conect
    {
        public IMongoCollection<Nota> conect(){//obtener todas las notas
            try
            {
                var client = new MongoClient("mongodb://localhost:27017");
                var bdd = client.GetDatabase("NotesBDD");
                var notesCollection = bdd.GetCollection<Nota>("Notes");
                MessageBox.Show("Conectado");
                return notesCollection;
            }
            catch (MongoException e)
            {
                MessageBox.Show("No se conecto");
                return null;
            }
        }

    }
}


