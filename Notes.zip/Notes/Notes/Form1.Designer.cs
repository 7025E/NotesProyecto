﻿namespace Notes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            dataGridView = new DataGridView();
            IDC = new DataGridViewTextBoxColumn();
            TittleC = new DataGridViewTextBoxColumn();
            ContentC = new DataGridViewTextBoxColumn();
            TagsC = new DataGridViewTextBoxColumn();
            DateC = new DataGridViewTextBoxColumn();
            saveBTN = new Button();
            titleTA = new TextBox();
            contentTA = new TextBox();
            tagTA = new TextBox();
            createdDateTA = new TextBox();
            IDTA = new TextBox();
            deleteSelectionBTN = new Button();
            updateBTN = new Button();
            deleteBTN = new Button();
            searchTA = new TextBox();
            searchBTN = new Button();
            reloadBTN = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView).BeginInit();
            SuspendLayout();
            // 
            // dataGridView
            // 
            dataGridView.AllowUserToAddRows = false;
            dataGridView.AllowUserToDeleteRows = false;
            dataGridView.AllowUserToResizeColumns = false;
            dataGridView.AllowUserToResizeRows = false;
            dataGridView.BackgroundColor = SystemColors.Window;
            dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView.Columns.AddRange(new DataGridViewColumn[] { IDC, TittleC, ContentC, TagsC, DateC });
            dataGridView.EnableHeadersVisualStyles = false;
            dataGridView.GridColor = SystemColors.ActiveBorder;
            dataGridView.Location = new Point(12, 14);
            dataGridView.Name = "dataGridView";
            dataGridView.ReadOnly = true;
            dataGridView.RowHeadersVisible = false;
            dataGridView.RowHeadersWidth = 51;
            dataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView.Size = new Size(246, 399);
            dataGridView.TabIndex = 1;
            dataGridView.CellClick += dataGridView_CellClick;
            dataGridView.CellContentClick += dataGridView_CellContentClick;
            // 
            // IDC
            // 
            IDC.HeaderText = "ID";
            IDC.MinimumWidth = 6;
            IDC.Name = "IDC";
            IDC.ReadOnly = true;
            IDC.Visible = false;
            IDC.Width = 125;
            // 
            // TittleC
            // 
            TittleC.HeaderText = "Titulo";
            TittleC.MinimumWidth = 6;
            TittleC.Name = "TittleC";
            TittleC.ReadOnly = true;
            TittleC.Width = 125;
            // 
            // ContentC
            // 
            ContentC.HeaderText = "Contenido";
            ContentC.MinimumWidth = 6;
            ContentC.Name = "ContentC";
            ContentC.ReadOnly = true;
            ContentC.Width = 125;
            // 
            // TagsC
            // 
            TagsC.HeaderText = "Tags";
            TagsC.MinimumWidth = 6;
            TagsC.Name = "TagsC";
            TagsC.ReadOnly = true;
            TagsC.Width = 125;
            // 
            // DateC
            // 
            DateC.HeaderText = "Fecha";
            DateC.MinimumWidth = 6;
            DateC.Name = "DateC";
            DateC.ReadOnly = true;
            DateC.Width = 125;
            // 
            // saveBTN
            // 
            saveBTN.Location = new Point(264, 386);
            saveBTN.Name = "saveBTN";
            saveBTN.Size = new Size(110, 29);
            saveBTN.TabIndex = 3;
            saveBTN.Text = "Guardar";
            saveBTN.UseVisualStyleBackColor = true;
            saveBTN.Click += button1_Click;
            // 
            // titleTA
            // 
            titleTA.Font = new Font("BIZ UDPGothic", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            titleTA.Location = new Point(260, 58);
            titleTA.Name = "titleTA";
            titleTA.Size = new Size(653, 34);
            titleTA.TabIndex = 7;
            titleTA.Text = "Sin titulo";
            titleTA.MouseDown += mouseDownTitle;
            // 
            // contentTA
            // 
            contentTA.Location = new Point(260, 94);
            contentTA.Multiline = true;
            contentTA.Name = "contentTA";
            contentTA.Size = new Size(653, 259);
            contentTA.TabIndex = 8;
            contentTA.Text = "Sin texto";
            contentTA.MouseDown += mouseDownContent;
            // 
            // tagTA
            // 
            tagTA.Location = new Point(260, 351);
            tagTA.Name = "tagTA";
            tagTA.Size = new Size(332, 27);
            tagTA.TabIndex = 9;
            tagTA.Tag = "";
            tagTA.Text = "sin tag";
            tagTA.MouseDown += mouseDownTags;
            // 
            // createdDateTA
            // 
            createdDateTA.BackColor = SystemColors.Window;
            createdDateTA.Location = new Point(589, 351);
            createdDateTA.Name = "createdDateTA";
            createdDateTA.ReadOnly = true;
            createdDateTA.Size = new Size(324, 27);
            createdDateTA.TabIndex = 12;
            // 
            // IDTA
            // 
            IDTA.Font = new Font("Segoe UI", 1F);
            IDTA.Location = new Point(654, 401);
            IDTA.Name = "IDTA";
            IDTA.ReadOnly = true;
            IDTA.Size = new Size(10, 10);
            IDTA.TabIndex = 13;
            // 
            // deleteSelectionBTN
            // 
            deleteSelectionBTN.Font = new Font("Segoe UI", 9F);
            deleteSelectionBTN.Location = new Point(630, 386);
            deleteSelectionBTN.Name = "deleteSelectionBTN";
            deleteSelectionBTN.Size = new Size(132, 29);
            deleteSelectionBTN.TabIndex = 14;
            deleteSelectionBTN.Text = "Eliminar selecion";
            deleteSelectionBTN.UseVisualStyleBackColor = true;
            deleteSelectionBTN.Click += deleteSelectionBTN_Click;
            // 
            // updateBTN
            // 
            updateBTN.Location = new Point(380, 386);
            updateBTN.Name = "updateBTN";
            updateBTN.Size = new Size(119, 29);
            updateBTN.TabIndex = 15;
            updateBTN.Text = "Modificar";
            updateBTN.UseVisualStyleBackColor = true;
            updateBTN.Click += updateBTN_Click;
            // 
            // deleteBTN
            // 
            deleteBTN.Location = new Point(505, 386);
            deleteBTN.Name = "deleteBTN";
            deleteBTN.Size = new Size(119, 29);
            deleteBTN.TabIndex = 16;
            deleteBTN.Text = "Eliminar";
            deleteBTN.UseVisualStyleBackColor = true;
            deleteBTN.Click += deleteBTN_Click;
            // 
            // searchTA
            // 
            searchTA.Location = new Point(436, 25);
            searchTA.Name = "searchTA";
            searchTA.Size = new Size(477, 27);
            searchTA.TabIndex = 17;
            // 
            // searchBTN
            // 
            searchBTN.Location = new Point(264, 23);
            searchBTN.Name = "searchBTN";
            searchBTN.Size = new Size(166, 29);
            searchBTN.TabIndex = 19;
            searchBTN.Text = "Buscar (tags/titulo):";
            searchBTN.UseVisualStyleBackColor = true;
            searchBTN.Click += searchBTN_Click;
            // 
            // reloadBTN
            // 
            reloadBTN.Location = new Point(768, 386);
            reloadBTN.Name = "reloadBTN";
            reloadBTN.Size = new Size(145, 29);
            reloadBTN.TabIndex = 20;
            reloadBTN.Text = "Recargar";
            reloadBTN.UseVisualStyleBackColor = true;
            reloadBTN.Click += reloadBTN_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            ClientSize = new Size(915, 427);
            Controls.Add(reloadBTN);
            Controls.Add(searchBTN);
            Controls.Add(searchTA);
            Controls.Add(deleteBTN);
            Controls.Add(updateBTN);
            Controls.Add(deleteSelectionBTN);
            Controls.Add(IDTA);
            Controls.Add(createdDateTA);
            Controls.Add(tagTA);
            Controls.Add(contentTA);
            Controls.Add(titleTA);
            Controls.Add(saveBTN);
            Controls.Add(dataGridView);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "Notes";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        //private Button ConectBtn;
        private DataGridView dataGridView;
        //private Button insertBTN;
        private Button saveBTN;
        private TextBox titleTA;
        private TextBox contentTA;
        private TextBox tagTA;
        private TextBox createdDateTA;
        private TextBox IDTA;
        private Button deleteSelectionBTN;
        private Button updateBTN;
        private Button deleteBTN;
        private TextBox searchTA;
        private Button searchBTN;
        private DataGridViewTextBoxColumn IDC;
        private DataGridViewTextBoxColumn TittleC;
        private DataGridViewTextBoxColumn ContentC;
        private DataGridViewTextBoxColumn TagsC;
        private DataGridViewTextBoxColumn DateC;
        private Button reloadBTN;
    }
}
